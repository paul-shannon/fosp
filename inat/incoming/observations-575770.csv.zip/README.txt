Exported at 2025-05-18T23:02:04Z

Query: quality_grade=any&identifications=any&projects%5B%5D=western-sword-fern-decline-in-the-pacific-northwest

Columns:
id: Unique, sequential identifier for the observation
uuid: Universally unique identifier for the observation. See https://datatracker.ietf.org/doc/html/rfc9562
observed_on_string: Date/time as entered by the observer
observed_on: Normalized date of observation
time_observed_at: Normalized datetime of observation
time_zone: Time zone of observation
user_id: Unique, sequential identifier for the observer
user_login: Handle / username of the observer, i.e. a short, unique, alphanumeric identifier for a user
user_name: Name of the observer, generally used for attribution on the site. This is an optional field and may be a pseudonym
created_at: Datetime observation was created
updated_at: Datetime observation was last updated
quality_grade: Quality grade of this observation. See Help section for details on what this means. See https://help.inaturalist.org/support/solutions/articles/151000169936
license: Identifier for the license or waiver the observer has chosen for this observation. All rights reserved if blank
url: URL for the observation
image_url: URL for the first photo associated with the observation
sound_url: URL for the first sound associated with the observation. Note this will only be present for direct uploads, not sounds hosted on 3rd-party services
tag_list: Comma-separated list of tags
description: Text written by the observer describing the observation or recording any other notes that seem relevant
num_identification_agreements: Number of identifications associated with taxa that match or are contained by the taxon from the observer's identification
num_identification_disagreements: Number of identifications associated with taxa that do not match and are not contained by the taxon from the observer's identification
captive_cultivated: Observation is of an organism that exists in the time and place it was observed because humans intended it to be then and there. For more, see https://help.inaturalist.org/support/solutions/articles/151000169932
oauth_application_id: Sequential identifier for the application that created the observation. For more information about the application, append this number to https://www.inaturalist.org/oauth/applications/
place_guess: Locality description as entered by the observer
latitude: Publicly visible latitude from the observation location
longitude: Publicly visible longitude from the observation location
positional_accuracy: Coordinate precision (yeah, yeah, accuracy != precision, poor choice of names)
private_place_guess: Observation location as written by the observer if location obscured
private_latitude: Private latitude, set if observation private or obscured
private_longitude: Private longitude, set if observation private or obscured
public_positional_accuracy: Maximum horizontal positional uncertainty in meters; includes uncertainty added by coordinate obscuration
geoprivacy: Whether or not the observer has chosen to obscure or hide the coordinates. See https://help.inaturalist.org/support/solutions/articles/151000169938
taxon_geoprivacy: Most conservative geoprivacy applied due to the conservation statuses of taxa in current identification.
coordinates_obscured: Whether or not the coordinates have been obscured, either because of geoprivacy or because of a threatened taxon
positioning_method: How the coordinates were determined
positioning_device: Device used to determine coordinates
place_town_name: The name of the town or city that contains this observation's coordinates, if known
place_county_name: The name of the third-level administrative area that contains this observation's coordinates (e.g. a county in most parts of the United States)
place_state_name: The name of the second-level administrative area that contains this observation's coordinates (e.g. a state in most parts of the United States)
place_country_name: The name of the country that contains this observation's coordinates
place_admin1_name: Name of the administrative place one rank below the country level
place_admin2_name: Name of the administrative place two ranks below the country level
species_guess: Plain text name of the observed taxon; can be set by the observer during observation creation, but can get replaced with canonical, localized names when the taxon changes
scientific_name: Scientific name of the observed taxon according to iNaturalist
common_name: Common or vernacular name of the observed taxon according to iNaturalist
iconic_taxon_name: Higher-level taxonomic category for the observed taxon
taxon_id: Unique, sequential identifier for the observed taxon
field:dbh+%28inches%29: https://www.inaturalist.org/terminology/field:dbh+%2528inches%2529
field:dmr.1: https://www.inaturalist.org/terminology/field:dmr.1
field:dmr.2: https://www.inaturalist.org/terminology/field:dmr.2
field:dmr.3: https://www.inaturalist.org/terminology/field:dmr.3
field:estimated+height+of+tree+%28ft%29: https://www.inaturalist.org/terminology/field:estimated+height+of+tree+%2528ft%2529
field:notes: https://www.inaturalist.org/terminology/field:notes
field:number+of+additional+unhealthy+trees+%28of+same+species%29+in+area+%28within+sight%29: https://www.inaturalist.org/terminology/field:number+of+additional+unhealthy+trees+%2528of+same+species%2529+in+area+%2528within+sight%2529
field:optional+-+aspect+or+direction+the+slope+is+facing: https://www.inaturalist.org/terminology/field:optional+-+aspect+or+direction+the+slope+is+facing
field:optional+-+can+we+follow+up+with+you%3F: https://www.inaturalist.org/terminology/field:optional+-+can+we+follow+up+with+you%253F
field:optional+-+estimated+time+spent+to+make+this+observation+%28%23+of+minutes%29: https://www.inaturalist.org/terminology/field:optional+-+estimated+time+spent+to+make+this+observation+%2528%2523+of+minutes%2529
field:optional+-+site+hydrology: https://www.inaturalist.org/terminology/field:optional+-+site+hydrology
field:optional+-+site+type: https://www.inaturalist.org/terminology/field:optional+-+site+type
field:optional+-+site%2Farea+disturbance+level: https://www.inaturalist.org/terminology/field:optional+-+site%252Farea+disturbance+level
field:optional+-+site%2Flocation+description: https://www.inaturalist.org/terminology/field:optional+-+site%252Flocation+description
field:optional+-+slope+position: https://www.inaturalist.org/terminology/field:optional+-+slope+position
field:optional+-+timing+of+symptoms+estimate: https://www.inaturalist.org/terminology/field:optional+-+timing+of+symptoms+estimate
field:optional+-+tree+canopy+transparancy: https://www.inaturalist.org/terminology/field:optional+-+tree+canopy+transparancy
field:optional+-+tree+size: https://www.inaturalist.org/terminology/field:optional+-+tree+size
field:optional+-+were+there+any+other+unhealthy+plant+species+on+the+site%3F: https://www.inaturalist.org/terminology/field:optional+-+were+there+any+other+unhealthy+plant+species+on+the+site%253F
field:optional+-+what+%27other+factors%27+were+observed%3F: https://www.inaturalist.org/terminology/field:optional+-+what+%2527other+factors%2527+were+observed%253F
field:other+factors+-+are+there+signs+or+symptoms+of+insect%2C+diseases%2C+or+other+damage%3F: https://www.inaturalist.org/terminology/field:other+factors+-+are+there+signs+or+symptoms+of+insect%252C+diseases%252C+or+other+damage%253F
field:percent+canopy+affected+%28%25%29: https://www.inaturalist.org/terminology/field:percent+canopy+affected+%2528%2525%2529
field:percent+of+trees+%28of+same+species%29+within+sight+that+are+unhealthy: https://www.inaturalist.org/terminology/field:percent+of+trees+%2528of+same+species%2529+within+sight+that+are+unhealthy
field:tree+canopy+symptoms: https://www.inaturalist.org/terminology/field:tree+canopy+symptoms

For more information about column headers, see https://www.inaturalist.org/terminology

